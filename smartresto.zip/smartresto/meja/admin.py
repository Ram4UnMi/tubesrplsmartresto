from django.contrib import admin
from .models import Meja

# Register your models here.
admin.site.register(Meja)