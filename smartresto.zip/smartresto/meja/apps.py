from django.apps import AppConfig


class MejaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'meja'
